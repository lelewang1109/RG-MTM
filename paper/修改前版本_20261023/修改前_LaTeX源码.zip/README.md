# 当前LaTeX源码

唯一编辑入口：`main.tex`（正文）和 `supplement.tex`（补充），共同使用 `refs.bib`。正文28个、补充25个递归TeX输入（含各自入口）；共享模块不复制。

最终PDF在 `../Revised_RG-MTM.pdf` 与 `../Revised_Supplement.pdf`，本目录同名编译PDF路径通过相对链接兼容。`figures/`中的当前图件同样链接到 `../../figures_export/`，源码ZIP会打包实体，能独立编译。

旧 `main_content.tex` 只是未参与编译的展开快照，现已归档，避免双入口。不可达的旧伪代码与旧图包装TeX已归档。`.bbl` 保留为当前参考文献编译材料，旧辅助文件已移出。

继续编辑请读 [正文与附录材料索引](../../../docs/正文与附录材料索引.md)、[当前大纲](../../MANUSCRIPT_OUTLINE.md) 和 [证据边界](../../../docs/研究证据边界与补充研究.md)。编译建议输出到独立构建目录；确认版面后再更新交付PDF并重打包。
