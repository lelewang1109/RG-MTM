# AnchorMTM Overleaf Project

Main file: `main.tex`  
Recommended compiler: **XeLaTeX**  
Bibliography processor: **BibTeX** (`abbrv-doi-narrow.bst`)  
Template: the original VGTC class, with the baseline `review` option, anonymous authors, and submission ID preserved.

## Upload to Overleaf

1. Choose **New Project → Upload Project** and upload `AnchorMTM_Overleaf.zip`.
2. Set the main document to `main.tex`.
3. Select **XeLaTeX** in the compiler settings and recompile. Overleaf handles BibTeX automatically.
4. If references remain unresolved after changing the main file, use **Recompile from scratch**.
5. To build the existing supplementary methods, select `supplementary.tex`, then switch back to `main.tex` for the paper.

The ZIP contains files directly at its root. All graphics, section inputs, tables, the bibliography, class and bibliography style are included. There are no external file paths, generated-data requirements, shell-escape steps, Python dependencies or network data requests for compiling the manuscript. Python is used only by the optional read-only content audit.

## Local compilation

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Alternatively run:

```sh
xelatex main.tex
bibtex main
xelatex main.tex
xelatex main.tex
```

The delivered project was locally checked with Tectonic's XeTeX engine and its BibTeX workflow, including a second build after extraction into an independent temporary directory. The Overleaf website itself was not used for this validation.

## Project layout

- `sections/`: seven narrative sections.
- `figures/`: all 13 figure PDFs. Twelve are byte-identical to the baseline; the workflow is the subsequently requested PPTX export.
- `tables/`: all five original table environments, with unchanged contents.
- `references.bib`: the complete original bibliography.
- `supplementary/content.tex`: existing supplementary methods; `supplementary.tex` is its root entry point.
- `vgtc.cls`, `abbrv-doi-narrow.bst`: original template files.
- `audit/`: source manifest, baseline text, preservation checks and before/after paragraphs. `audit/baseline_main.tex` is a reference snapshot, not a compilation entry point.

No experiment was rerun. No figure was redrawn; the workflow alone was replaced by a native PDF export of the subsequently supplied PPTX. The only changes are narrative prose, section organization, relative-path packaging and permitted float placement/width adjustments.

Run the optional preservation check with:

```sh
python3 audit/check_invariants.py
```

## 后续流程图替换

用户明确指定 `AnchorMTM_流程图_论文配色_布局优化.pptx` 后，本工程将其单页直接导出为论文Figure 5使用的PDF，替换 `figures/anchor_framework.pdf`，保留其余12图不变。新图的layout面板合并展示选序与锚点放置，文字和图注据此对应，算法定义、公式和实验结果未改。源PPTX保存在 `figure_sources/framework_requested.pptx`。
